# Virtual-assistent
Mephi project by Alex Lepekhov and Alexey Chernyakov
